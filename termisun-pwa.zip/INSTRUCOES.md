# Termisun — Instalação GitHub Pages + PWA

## O que é e como funciona

A Termisun é uma PWA (Progressive Web App). Isso significa:
- Funciona no browser como qualquer site
- Pode ser instalada no telemóvel como uma app normal
- Funciona offline depois da primeira visita
- Não precisa de App Store nem Google Play
- Gratuito para sempre

---

## PASSO 1 — Criar conta GitHub (se ainda não tiver)

1. Aceda a https://github.com
2. Clique em **Sign up**
3. Escolha um username (ex: `empresa-termisun`)
4. Confirme o email

---

## PASSO 2 — Criar o repositório

1. Depois de fazer login, clique no **+** (canto superior direito)
2. Seleccione **New repository**
3. Preencha:
   - **Repository name:** `termisun`
   - Marque **Public** (obrigatório para GitHub Pages gratuito)
   - Deixe tudo o resto em branco
4. Clique **Create repository**

---

## PASSO 3 — Fazer upload dos ficheiros

Na página do repositório que acabou de criar:

1. Clique em **uploading an existing file**
2. **Arraste a pasta `icons`** (com os 3 ficheiros dentro) para a área de upload
3. **Arraste também** os ficheiros `index.html`, `manifest.json` e `sw.js`
4. A estrutura final deve ficar assim:
   ```
   termisun/
   ├── index.html
   ├── manifest.json
   ├── sw.js
   └── icons/
       ├── icon-192.png
       ├── icon-512.png
       └── apple-touch-icon.png
   ```
5. Em baixo escreva uma mensagem (ex: `primeira versão`) e clique **Commit changes**

---

## PASSO 4 — Activar o GitHub Pages

1. No repositório, clique em **Settings** (menu de cima)
2. No menu esquerdo clique em **Pages**
3. Em **Source** seleccione **Deploy from a branch**
4. Em **Branch** escolha **main** e pasta **/ (root)**
5. Clique **Save**
6. Aguarde 2 a 3 minutos

O link da app fica disponível em:
```
https://SEU-USERNAME.github.io/termisun/
```
(substitua SEU-USERNAME pelo seu username do GitHub)

---

## PASSO 5 — Instalar no telemóvel

### Android (Chrome)
1. Abra o link no **Chrome**
2. Aparece uma barra em baixo com "Adicionar Termisun ao ecrã inicial"
3. Toque em **Instalar** (ou **Adicionar**)
4. A app aparece no ecrã principal como qualquer outra

Se o banner não aparecer:
- Toque nos **três pontos** (menu do Chrome)
- Seleccione **Adicionar ao ecrã principal**

### iPhone / iPad (Safari)
1. Abra o link no **Safari** (não funciona no Chrome do iPhone)
2. Toque no botão de **partilha** (□ com seta para cima, em baixo no ecrã)
3. Deslize e toque em **Adicionar ao Ecrã de Início**
4. Confirme com **Adicionar**
5. A app aparece no ecrã inicial com o ícone azul do Termisun

---

## Credenciais iniciais

| Campo | Valor |
|-------|-------|
| Utilizador | `admin` |
| Palavra-passe | `admin1234` |

⚠️ Altere a palavra-passe do admin logo após instalar.
Vá a **Users** → apague o admin → crie um novo com palavra-passe segura.

---

## Partilhar com os funcionários

Basta enviar o link por WhatsApp, email ou SMS:
```
https://SEU-USERNAME.github.io/termisun/
```
Cada funcionário instala no seu telemóvel em menos de 1 minuto.

---

## Guardar o link permanentemente

Marque o link nos favoritos do browser ou guarde-o num documento interno.
O link não muda enquanto o repositório existir no GitHub.
